Dayana Gonzalez Cruz
CST-310: Computer Graphics Lecture & Lab
TR1100A Dr. Citro
09/08/24

Follow these step-by-step instructions to set up your system and successfully compile and execute the accompanying C++ files within this project. 

Install WSL (Windows Subsystem for Linux):
- Open terminal
- Install Wsl
	- Enter wsl --install into terminal
- Launch Ubuntu
	- Go to start menu
	- Search "Ubuntu" and click on result 
- Set Username and Password following terminal prompts
- Update Ubuntu
	- Enter in terminal: sudo apt update
Install Necessary Libraries:
- Enter in terminal : sudo apt-get install libglu1-mesa-dev freeglut3-dev mesa-common-dev
- Traverse file system to where .cpp Sierpinski2D and Sierpinski3D files are located
- Open terminal in this folder
Compile Programs:
g++ Sierpinski2D.cpp -o Sierpinski2D -lglut -lGLU -lGL
or 
g++ Sierpinski3D.cpp -o Sierpinski3D -lglut -lGLU -lGL
Run the Programs:
./Sierpinski2D
./Sierpinski3D
