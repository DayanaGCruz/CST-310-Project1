// Dayana Gonzalez Cruz
// CST-310: Computer Graphics Lecture & Lab
// TR1100A Dr. Citro
// 09/08/24
// This program was provided by the instructor for student to add comments and use as a learning tool.
// This program generates a Sierpinski gasket with 10000 points.

// Include OpenGL utility library GLUT and general purpose CSTDLIB. 
#ifdef __APPLE_CC__
#include <GLUT/glut.h> // Apple Ver. GLUT
#else
#include <GL/glut.h> // Standard Ver. GLUT
#endif
#include <cstdlib> // Standard Library

// A simple two-dimensional point class to make life easy.  It allows you to
// reference points with x and y coordinates instead of array indices) and
// encapsulates a midpoint function.
struct Point {
  GLfloat x, y;  // Two attributes: x and y coordinates.
  Point(GLfloat x = 0, GLfloat y = 0): x(x), y(y) {} // Constructor with default values for x and y.
  Point midpoint(Point p) {return Point((x + p.x) / 2.0, (y + p.y) / 2.0);}  // Calculate the midpoint between this point and another point.
};

// Draws a Sierpinski triangle with a fixed number of points. (Note that the
// number of points is kept fairly small because a display callback should
// NEVER run for too long.
void display() {

  glClear(GL_COLOR_BUFFER_BIT); // Clear the window to the background color.

  static Point vertices[] = {Point(0, 0), Point(200, 500), Point(500, 0)};   // Define three vertices of the triangle.

  // Compute and plot 100000 new points, starting (arbitrarily) with one of
  // the vertices. Each point is halfway between the previous point and a
  // randomly chosen vertex.
  static Point p = vertices[0];  // Start with an arbitrary point (here the first vertex).
  glBegin(GL_POINTS);   // Begin drawing points.
  for (int k = 0; k < 100000; k++) { // Loop to compute and plot 100000 points.
    p = p.midpoint(vertices[rand() % 3]);  // Choose a random vertex and compute the midpoint with the current point.
    glVertex2f(p.x, p.y); // Plot the new point.
  }
  glEnd();  // End drawing points.
  glFlush();    // Force execution of OpenGL commands in finite time.
}

// Performs application-specific initialization. Sets colors and sets up a
// simple orthographic projection.
void init() {

  // Set a deep purple background and draw in a greenish yellow.
  glClearColor(0.25, 0.0, 0.2, 1.0);
  glColor3f(0.6, 1.0, 0.0);

  // Set up the viewing volume: 500 x 500 x 1 window with origin lower left.
  glMatrixMode(GL_PROJECTION); // Switch to the projection matrix.
  glLoadIdentity(); // Reset the projection matrix.
  glOrtho(0.0, 500.0, 0.0, 500.0, 0.0, 1.0); // Define the 2D orthographic projection with given coordinates.
}

// Initializes GLUT, the display mode, and main window; registers callbacks;
// does application initialization; enters the main event loop.
int main(int argc, char** argv) {
  glutInit(&argc, argv); // Initialize GLUT with command-line arguments.
  glutInitDisplayMode (GLUT_SINGLE | GLUT_RGB); // Set display mode to single-buffered and RGB.
  glutInitWindowSize(500, 500); // Set window size to 500 x 500.
  glutInitWindowPosition(40, 40); // Set window position on the screen.
  glutCreateWindow("Sierpinski Triangle 2D"); // Create a window with the title "Sierpinski Triangle 2D".
  glutDisplayFunc(display); // Register the display callback function.
  init(); // Call the application-specific initialization function.
  glutMainLoop(); // Enter the GLUT event processing loop.
}
